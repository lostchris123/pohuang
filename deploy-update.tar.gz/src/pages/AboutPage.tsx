import React from 'react'
import { motion } from 'framer-motion'
import { 
  Brain, 
  Target, 
  Rocket, 
  Users,
  Award,
  Lightbulb,
  Heart,
  Globe
} from 'lucide-react'

const AboutPage: React.FC = () => {
  const timeline = [
    {
      year: '2020',
      title: '公司成立',
      description: '杭州破荒人工智能科技有限公司正式成立，开启AI技术创新之路'
    },
    {
      year: '2021',
      title: '产品发布',
      description: '爆款捕手、数字人平台等核心产品相继上线，获得市场认可'
    },
    {
      year: '2022',
      title: '快速增长',
      description: '服务客户突破100家，处理数据量达500万+，业务快速扩张'
    },
    {
      year: '2023',
      title: '行业领先',
      description: '成为AI技术服务领域领先企业，获得多项行业大奖与专利认证'
    },
    {
      year: '2024',
      title: '生态构建',
      description: '构建完整的AI产品生态矩阵，为企业提供一站式数字化解决方案'
    }
  ]

  const team = [
    {
      name: '技术团队',
      count: '50+',
      description: '来自阿里巴巴、百度等一线互联网公司的AI技术专家',
      icon: <Brain className="w-8 h-8" />
    },
    {
      name: '产品团队',
      count: '20+',
      description: '资深产品经理，深耕行业多年，深刻理解企业需求',
      icon: <Lightbulb className="w-8 h-8" />
    },
    {
      name: '服务团队',
      count: '30+',
      description: '专业客户服务团队，提供7x24小时技术支持',
      icon: <Heart className="w-8 h-8" />
    },
    {
      name: '市场团队',
      count: '15+',
      description: '市场运营专家，助力企业实现商业价值最大化',
      icon: <Globe className="w-8 h-8" />
    }
  ]

  const values = [
    {
      icon: <Target className="w-12 h-12" />,
      title: '精准',
      description: '精准理解客户需求，精准定位市场机遇，精准提供解决方案'
    },
    {
      icon: <Rocket className="w-12 h-12" />,
      title: '创新',
      description: '持续技术创新，不断突破边界，引领行业发展方向'
    },
    {
      icon: <Users className="w-12 h-12" />,
      title: '共赢',
      description: '与客户共同成长，与合作伙伴共同发展，共创商业价值'
    },
    {
      icon: <Award className="w-12 h-12" />,
      title: '卓越',
      description: '追求卓越品质，打造极致体验，成就客户成功'
    }
  ]

  const certifications = [
    '国家高新技术企业',
    'ISO 27001信息安全认证',
    'AAA级信用企业',
    '人工智能产业联盟成员',
    '杭州市重点科技企业',
    '瞪羚企业'
  ]

  return (
    <div className="overflow-hidden">
      {/* Hero区域 */}
      <section className="section-padding bg-gradient-to-br from-primary-blue/10 to-accent-purple/10 relative">
        <div className="container-responsive">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-black mb-6">
              <span className="text-gradient">关于破荒AI</span>
            </h1>
            <p className="text-xl text-secondary-lightGray max-w-3xl mx-auto leading-relaxed">
              杭州破荒人工智能科技有限公司，专注于AI技术研发与应用，致力于为企业提供智能化转型解决方案，引领人工智能产业创新发展
            </p>
          </motion.div>

          {/* 企业使命愿景 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: '使命', content: '用AI技术赋能企业，让智能化惠及每一个组织' },
              { title: '愿景', content: '成为最值得信赖的AI技术服务提供商' },
              { title: '价值观', content: '破荒前行，智创未来，追求卓越，合作共赢' }
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all"
              >
                <h3 className="text-2xl font-bold mb-4 text-primary-blue">{item.title}</h3>
                <p className="text-secondary-gray leading-relaxed">{item.content}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* 装饰元素 */}
        <div className="absolute top-20 right-10 w-64 h-64 bg-primary-blue/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-48 h-48 bg-accent-purple/5 rounded-full blur-3xl" />
      </section>

      {/* 发展历程 */}
      <section className="section-padding">
        <div className="container-responsive">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              <span className="text-gradient">发展历程</span>
            </h2>
            <p className="text-xl text-secondary-lightGray">
              破荒AI的成长足迹
            </p>
          </motion.div>

          <div className="relative">
            {/* 时间轴线 */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-primary-blue to-accent-purple hidden md:block" />

            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? 'md:pr-12 md:text-right' : 'md:pl-12'}`}>
                    <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all">
                      <div className="text-3xl font-black text-gradient mb-2">{item.year}</div>
                      <h3 className="text-xl font-bold mb-2 text-secondary-darkGray">{item.title}</h3>
                      <p className="text-secondary-lightGray">{item.description}</p>
                    </div>
                  </div>
                  
                  {/* 时间点 */}
                  <div className="hidden md:flex items-center justify-center w-12 h-12 rounded-full bg-gradient-to-r from-primary-blue to-accent-purple text-white font-bold text-sm shadow-lg">
                    {item.year}
                  </div>
                  
                  <div className="flex-1 hidden md:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 团队介绍 */}
      <section className="section-padding bg-secondary-silver/30">
        <div className="container-responsive">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              <span className="text-gradient">核心团队</span>
            </h2>
            <p className="text-xl text-secondary-lightGray">
              专业、专注、专心的精英团队
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all text-center"
              >
                <div className="inline-flex p-4 rounded-2xl bg-gradient-to-br from-primary-blue to-accent-purple text-white mb-6">
                  {member.icon}
                </div>
                <div className="text-4xl font-black text-gradient mb-2">{member.count}</div>
                <h3 className="text-xl font-bold mb-3 text-secondary-darkGray">{member.name}</h3>
                <p className="text-secondary-lightGray text-sm">{member.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 核心价值观 */}
      <section className="section-padding">
        <div className="container-responsive">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              <span className="text-gradient">核心价值观</span>
            </h2>
            <p className="text-xl text-secondary-lightGray">
              指引我们前行的精神力量
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="inline-flex p-6 rounded-3xl bg-white shadow-lg mb-6">
                  <div className="text-primary-blue">{value.icon}</div>
                </div>
                <h3 className="text-2xl font-bold mb-3 text-secondary-darkGray">{value.title}</h3>
                <p className="text-secondary-lightGray">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 资质认证 */}
      <section className="section-padding bg-gradient-to-br from-secondary-darkGray to-secondary-gray text-white">
        <div className="container-responsive">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-black mb-4">资质认证</h2>
            <p className="text-xl text-secondary-silver">
              专业实力，权威认证
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {certifications.map((cert, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 text-center hover:bg-white/20 transition-all"
              >
                <div className="text-sm font-semibold">{cert}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

export default AboutPage